<?php 

class db {

		//Enter database details here
		public $Hostname = "localhost";
		public $Username = "root";
		public $Password = "1235";
		public $Database = "myshop";

		public $Connection;

		//Connect to Database
		public function __construct() {
			$this->Connection = mysqli_connect($this->Hostname, $this->Username, $this->Password, $this->Database) or die("Database error");
		}
		
		//Disconnect from Database
		public function __destruct() {
			@mysqli_free_result($result);
			mysqli_close( $this->Connection );
		}
		//Query Database
        public function db_query($Query) {
       		$result = mysqli_query( $this->Connection, $Query );
			if($result){
				return $result;
			}else{
				return false;
			}
        }
        public function cal_num_rows($query){
          	$result = $this->db_query($query);
          	if($result){
          		return $this->db_rows($result);
          	}
			return 0;
        }  
        //Get number of rows
    	public function db_rows($result)
    	{
    		return ( mysqli_num_rows ($result) );
			
    	}
    	public function get_items_as_array($result)
    	{
    		$temp = array();
    		while ($row = $result->fetch_assoc()) {
				$temp[] = $row;
			}
			return $temp;
    	}
    	public function get_item_as_obj($result)
    	{
    		while ($row = $result->fetch_assoc()) {
				return $row;
			}
    	}
    	public function db_insert_query($Query) {
			$result = mysqli_query( $this->Connection, $Query );
			if($result){
				return $this->Connection->insert_id;
			}else{
				return false;
			}
		}
		public function mysql_affected_rows($result)
		{
			return mysql_affected_rows($result);
		}
    	//Get result
    	public function db_rs($result) 
    	{
    		return ( @mysqli_fetch_array($result) );
    	}
    	//Get row
    	public function db_row($result)
    	{
    		return mysqli_fetch_row ($result) ;
    	}
		//Sanitise String
		public function sanitise($string){
			if(get_magic_quotes_gpc()) $string = stripslashes($string);
			return mysqli_real_escape_string($this->Connection, $string);
		}
	}

?>