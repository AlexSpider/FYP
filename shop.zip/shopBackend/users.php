<?php

	class Users {
		public $DB;
		public function __construct($DB) {
			$this->DB = $DB;
		}
		public function reg($email, $pass)
		{
			$query = "SELECT * from customer ";
			$query .= " WHERE email = '".$email."'";
			$results = $this->DB->db_query($query);
			if($results && $this->DB->db_rows($results)){
				$obj = new stdClass();
				$obj->err = 205;
				return $obj;
			}
			$query = "INSERT INTO `customer` (`email`, `password`) VALUES ('".$email."', '".md5($pass)."')";
			$results = $this->DB->db_insert_query($query);
			if($results){
				$obj = new stdClass();
				$obj->ok = 1;
				return $obj;
			}
			return false;
		}
		public function login($email, $pass)
		{
			$query = "SELECT * from customer ";
			$query .= " WHERE email = '".$email."'";
			$results = $this->DB->db_query($query);

			if($results && $this->DB->db_rows($results)){
				$user = $this->DB->get_item_as_obj($results);
				if($user && $user['password'] == md5($pass)){
					$obj = new stdClass();
					$obj->ok = 1;
					$obj->user = $user['ID'];
					return $obj;
				}
			}

			$obj = new stdClass();
			$obj->err = 1;
			return $obj;
		}
	}

?>