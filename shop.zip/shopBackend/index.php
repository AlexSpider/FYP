<?php
    header('Access-Control-Allow-Origin: *');
    header('Content-Type: application/json');

	include( './db.php');
	include( './users.php');
	include( './shops.php');
	
	$DB = new db();
	$Shops = new Shops($DB);
	$Users = new Users($DB);

	function getCurrentUri()
	{
		$basepath = implode('/', array_slice(explode('/', $_SERVER['SCRIPT_NAME']), 0, -1)) . '/';
		$uri = substr($_SERVER['REQUEST_URI'], strlen($basepath));
		if (strstr($uri, '?')) $uri = substr($uri, 0, strpos($uri, '?'));
		$uri = '/' . trim($uri, '/');
		return $uri;
	}
 
	$base_url = getCurrentUri();
	$routes = array();
	$routes = explode('/', $base_url);

	$result = null;

	if($routes[1]=='shop'){	

		switch ($routes[2]) {
			case 'list': 
				$offset = (isset($_GET['offset'])) ? $_GET['offset'] : 0;
				$limit = (isset($_GET['limit'])) ? $_GET['limit'] : 12;
				$user_id = (isset($_GET['user_id'])) ? $_GET['user_id'] : 0;
				$result = $Shops->getShops($offset, $limit, $user_id);
				break;
			case 'one': 
				$id = (isset($_GET['id'])) ? $_GET['id'] : 0;
				if($id){
					$result = $Shops->getOneShop($id);
				}
				break;
			case 'remove': 
				$id = (isset($_GET['id'])) ? $_GET['id'] : 0;
				if($id){
					$result = $Shops->removeShop($id);
				}
				break;
			case 'add': 
				$user_id = (isset($_POST['user_id'])) ? $_POST['user_id'] : 0;
				$title = (isset($_POST['title'])) ? $_POST['title'] : '';
				$email = (isset($_POST['email'])) ? $_POST['email'] : '';
				$phone = (isset($_POST['phone'])) ? $_POST['phone'] : '';
				$address = (isset($_POST['address'])) ? $_POST['address'] : '';
				if($user_id || $title){
					$result = $Shops->addShop($user_id,$title,$email,$phone,$address);
				}
				break;
			case 'edit': 
				$id = (isset($_POST['id'])) ? $_POST['id'] : 0;
				$title = (isset($_POST['title'])) ? $_POST['title'] : '';
				$email = (isset($_POST['email'])) ? $_POST['email'] : '';
				$phone = (isset($_POST['phone'])) ? $_POST['phone'] : '';
				$address = (isset($_POST['address'])) ? $_POST['address'] : '';
				if($id || $title){
					$result = $Shops->editShop($id,$title,$email,$phone,$address);
				}
				break;
		}

	}elseif($routes[1]=='product'){

		switch ($routes[2]) {
			case 'list': 
				$shop_id = (isset($_GET['shop_id'])) ? $_GET['shop_id'] : 0;
				$limit = (isset($_GET['limit'])) ? $_GET['limit'] : 12;
				$offset = (isset($_GET['offset'])) ? $_GET['offset'] : 0;
				if($shop_id){
					$result = $Shops->getProducts($shop_id, $offset, $limit);
				}
				break;
			case 'one': 
				$id = (isset($_GET['id'])) ? $_GET['id'] : 0;
				if($id){
					$result = $Shops->getOneProduct($id);
				}
				break;
			case 'remove': 
				$id = (isset($_GET['id'])) ? $_GET['id'] : 0;
				if($id){
					$result = $Shops->removeProduct($id);
				}
				break;
			case 'add': 
				$shop_id = (isset($_POST['shop_id'])) ? $_POST['shop_id'] : 0;
				$title = (isset($_POST['title'])) ? $_POST['title'] : '';
				$descr = (isset($_POST['descr'])) ? $_POST['descr'] : '';
				$price = (isset($_POST['price'])) ? $_POST['price'] : '';
				if($shop_id && $title && $descr && $price){
					$result = $Shops->addProduct($shop_id, $title, $descr, $price);
				}
				break;
			case 'edit': 
				$id = (isset($_POST['id'])) ? $_POST['id'] : 0;
				$title = (isset($_POST['title'])) ? $_POST['title'] : '';
				$descr = (isset($_POST['descr'])) ? $_POST['descr'] : '';
				$price = (isset($_POST['price'])) ? $_POST['price'] : '';
				if($id && $title && $descr && $price){
					$result = $Shops->editProduct($id, $title, $descr, $price);
				}
				break;
		}

	}elseif($routes[1]=='user'){
		switch ($routes[2]) {
			case 'login': 
				$email = (isset($_POST['email'])) ? $_POST['email'] : false;
				$pass = (isset($_POST['pass'])) ? $_POST['pass'] : false;
				if($email && $pass){
					$result = $Users->login($email, $pass);
				}
				break;
			case 'reg': 
				$email = (isset($_POST['email'])) ? $_POST['email'] : false;
				$pass = (isset($_POST['pass'])) ? $_POST['pass'] : false;
				if($email && $pass){
					$result = $Users->reg($email, $pass);
				}
				break;
		}
	}
	
	if($result){
		echo json_encode($result);
	}else{
		header("HTTP/1.0 500 Not Found");
		echo "Server error.\n";
	}
?>