<?php

	class Shops {
		public $DB;
		public function __construct($DB) {
			$this->DB = $DB;
		}

		public function getShops( $offset = 0, $limit = 12, $user_id = null)
		{
			$query = "SELECT SQL_CALC_FOUND_ROWS  * from shoplist ";
			if($user_id) $query .= " WHERE user_id = " . $user_id;
			$count = $this->DB->cal_num_rows($query);

			$query .= " ORDER BY ID DESC";
			$query .= " LIMIT " . $offset . "," .  $limit;

			$results = $this->DB->db_query($query);

			if($results && $this->DB->db_rows($results)){
				$obj = new stdClass();
				$obj->ok = 1;
				$obj->items = $this->DB->get_items_as_array($results);
				$obj->count = $count;
				
				return $obj;
			}

			$obj = new stdClass();
			$obj->ok = 1;
			$obj->items = array();
			$obj->count = 0;
			
			return $obj;
		}
		public function getOneShop($id)
		{
			$query = "SELECT * from shoplist ";
			$query .= " WHERE ID = ".$id;
			$results = $this->DB->db_query($query);
			if($results && $this->DB->db_rows($results)){
				$obj = new stdClass();
				$obj->ok = 1;
				$obj->shop = $this->DB->get_item_as_obj($results);
				return $obj;
			}
			return false;
		}
		public function getProducts($shop_id, $offset = 0, $limit = 12)
		{
			$query = "SELECT SQL_CALC_FOUND_ROWS  * from productpage ";
			$query .=" WHERE shop_id = ".$shop_id;
			$count = $this->DB->cal_num_rows($query);
			$query .= " ORDER BY ID DESC";
			$query .= " LIMIT " . $offset . "," .  $limit;
			$results = $this->DB->db_query($query);
			if($results && $this->DB->db_rows($results)){
				$obj = new stdClass();
				$obj->ok = 1;
				$obj->items = $this->DB->get_items_as_array($results);
				$obj->count = $count;
				
				return $obj;
			}

			$obj = new stdClass();
			$obj->ok = 1;
			$obj->items = array();
			$obj->count = 0;
			
			return $obj;
		}
		public function getOneProduct($id)
		{
			$query = "SELECT * from productpage ";
			$query .= " WHERE ID = ".$id;
			$results = $this->DB->db_query($query);
			if($results && $this->DB->db_rows($results)){
				$obj = new stdClass();
				$obj->ok = 1;
				$obj->product = $this->DB->get_item_as_obj($results);
				return $obj;
			}
			return false;
		}
		public function addShop($user_id,$title,$email,$phone,$address)
		{
			$query = "INSERT INTO `shoplist` (`user_id`,`title`,`email`,`phone`,`address`) VALUES ('".$user_id."', '".$title."', '".$email."', '".$phone."', '".$address."')";
			$results = $this->DB->db_insert_query($query);
			if($results){
				$obj = new stdClass();
				$obj->ok = 1;
				return $obj;
			}
			return false;
		}
		public function addProduct($shop_id, $title, $descr, $price)
		{
			$query = "INSERT INTO `productpage` (`shop_id`,`title`,`descr`,`price`) VALUES ('".$shop_id."', '".$title."', '".$descr."', '".$price."')";
			$results = $this->DB->db_insert_query($query);
			if($results){
				$product = $this->getOneProduct($results);
				if($product){
					return $product;
				}
			}
			return false;
		}
		public function editShop($id,$title,$email,$phone,$address)
		{
			$query = "UPDATE `shoplist` SET `title`='".$title."', `email`='".$email."', `phone`='".$phone."', `address`='".$address."'";
			$query .= " WHERE ID = ".$id;
			$results = $this->DB->db_query($query);
			if($results){
				$obj = new stdClass();
				$obj->ok = 1;
				return $obj;
			}
			return false;
		}
		public function editProduct($id, $title, $descr, $price)
		{
			$query = "UPDATE `productpage` SET `title`='".$title."', `descr`='".$descr."', `price`='".$price."' ";
			$query .= " WHERE ID = ".$id;
			$results = $this->DB->db_query($query);
			if($results){
				$obj = new stdClass();
				$obj->ok = 1;
				return $obj;
			}
			return false;
		}
		public function removeShop($id)
		{
			$query = "DELETE FROM shoplist WHERE ID = " . $id;
			$results = $this->DB->db_query($query);
			if($results){
				$query = "DELETE FROM productpage WHERE shop_id = " . $id;
				$this->DB->db_query($query);
				$obj = new stdClass();
				$obj->ok = 1;
				return $obj;
			}
			return false;
		}
		public function removeProduct($id)
		{
			$query = "DELETE FROM productpage WHERE ID = " . $id;
			$results = $this->DB->db_query($query);
			if($results){
				$obj = new stdClass();
				$obj->ok = 1;
				return $obj;
			}
			return false;
		}
	}

?>