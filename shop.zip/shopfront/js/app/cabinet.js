define(['jfw.core', 'jquery', 'jfw.control', 'jfw.route', 'jfw.view', 'app/models', 'app/msg_map', 'app/utils'], 

	function(fw, $){

		var app = fw.extend(fw, 'app');
		var cabinet = fw.extend(fw, 'app.cabinet');
		var utils = fw.extend(fw, 'app.utils');

		cabinet._init = function(){
			$('#layout').append(fw.view('./js/app/cabinet/layout.ejs', {}));
			$('#layout').append(fw.view('./js/app/cabinet/addShop.ejs', {}));
			$('#layout').append(fw.view('./js/app/cabinet/editShop.ejs', {}));
			$('#layout').append(fw.view('./js/app/cabinet/editProduct.ejs', {}));

			cabinet.control = new cabinet_control('#cabinet-module');
			cabinet.addShop = new addShop_control('#add-shop-module');
			cabinet.editShop = new editShop_control('#edit-shop-module');
			cabinet.editProduct = new editProduct_control('#edit-product-module');
			cabinet.control.scrollInit();
		};

	var editProduct_control = fw.Control({
		init: function () {
			var module = this;
			this.active = false;
			app.msg_map.bind('active_module', function(e){
				if(e.new_val == 'editProduct'){
					module.active = true;
					module.element.removeClass('hidden');
				}else{
					module.active = false;
					module.element.addClass('hidden');
				}
			});
		},
		getProduct: function (id) {
			var module = this;
			module.currentId = id;
			app.models.Products.findOne( {id: id}, function(res){
				module.currentProduct = res.product;
				module.element.find('[name="product-title"]').val(res.product.title);
				module.element.find('[name="product-descr"]').val(res.product.descr);
				module.element.find('[name="product-price"]').val(res.product.price);
			});
		},
		'.btn-back click': function (e) {
			var module = e.data.self;
			console.log(module);
			window.location.hash = 'editShop/'+module.currentProduct.shop_id;
		},
		'.product-upload click': function () {
			$(this).closest('form').find('[name="product-logo"]').trigger('click');
		},
		'.update click': function (e) {
			e.preventDefault();
			var module = e.data.self;
			var title = module.element.find('[name="product-title"]').val();
			var descr = module.element.find('[name="product-descr"]').val();
			var price = module.element.find('[name="product-price"]').val();

			if(!title || !descr || !price){
				utils.createMessage('danger', 'Empty field');
				return false;
			}
			if( !(!isNaN(parseFloat(price)) && isFinite(price) ) ){
				utils.createMessage('danger', 'price not number');
				return false;
			}
			var model = new app.models.Products({id: module.currentId, title: title, descr: descr, price:price});
			model.update(function (res) {
				if(res.ok){
					utils.createMessage('success', 'product updated');
				}
			});
		}
	});

	var editShop_control = fw.Control({
		init: function () {
			var module = this;
			this.active = false;
			app.msg_map.bind('active_module', function(e){
				if(e.new_val == 'editShop'){
					module.active = true;
					module.element.removeClass('hidden');
				}else{
					module.active = false;
					module.element.addClass('hidden');
				}
			});
		},
		getShop: function (id) {
			var module = this;
			module.currentId = id;
			app.models.Shop.findOne( {id: id}, function(res){
				module.element.find('[name="shop-title"]').val(res.shop.title);
				module.element.find('[name="shop-email"]').val(res.shop.email);
				module.element.find('[name="shop-phone"]').val(res.shop.phone);
				module.element.find('[name="shop-address"]').val(res.shop.address);
			});
			app.models.Products.find( {shop_id: id}, function(res){
				module.element.find('.items-wrap').html(fw.view('./js/app/cabinet/productsListItem.ejs', { 
					items: res.items
				}));
			});
		},
		'.btn-back click': function (e) {
			var module = e.data.self;
			window.location.hash = 'cabinet';
		},
		'.shop-upload click': function () {
			$(this).closest('form').find('[name="shop-logo"]').trigger('click');
		},
		'.product-upload click': function () {
			$(this).closest('form').find('[name="product-logo"]').trigger('click');
		},
		'.remove-btn click': function (id) {
			var product = $(this).closest('.item-wrap');
			var productId = product.attr('data-id');

			var model = new app.models.Products({id:productId});
			model.destroy(function (res) {
				product.remove();
			});
		},
		'.edit-btn click': function (id) {
			var product = $(this).closest('.item-wrap');
			var productId = product.attr('data-id');
			window.location.hash = 'editProduct/'+productId;
		},
		'.add-product click': function (e) {
			e.preventDefault();
			var module = e.data.self;

			var title = module.element.find('[name="product-title"]').val();
			var descr = module.element.find('[name="product-descr"]').val();
			var price = module.element.find('[name="product-price"]').val();

			if(!title || !descr || !price){
				utils.createMessage('danger', 'Empty field');
				return false;
			}
			if( !(!isNaN(parseFloat(price)) && isFinite(price) ) ){
				utils.createMessage('danger', 'price not number');
				return false;
			}

			var model = new app.models.Products({
				shop_id: module.currentId,
				title: title,
				descr: descr,
				price:price
			});
			model.create(function (res) {
				if(res.ok){
					module.element.find('[name="product-title"]').val('');
					module.element.find('[name="product-descr"]').val('');
					module.element.find('[name="product-price"]').val('');
					utils.createMessage('success', 'product create');
					module.element.find('.items-wrap').prepend(fw.view('./js/app/cabinet/productsListItem.ejs', { 
						items: [res.product]
					}));
				}
			});
		},
		'.update click': function (e) {
			e.preventDefault();
			var module = e.data.self;
			var title = module.element.find('[name="shop-title"]').val();
			var email = module.element.find('[name="shop-email"]').val();
			var phone = module.element.find('[name="shop-phone"]').val();
			var address = module.element.find('[name="shop-address"]').val();

			if(!title || !email || !phone || !address){
				utils.createMessage('danger', 'Empty field');
				return false;
			}

			var model = new app.models.Shop({
				id: module.currentId,
				title: title,
				email: email,
				phone: phone,
				address: address
			});
			model.update(function (res) {
				if(res.ok){
					module.element.find('[name="shop-title"]').val('');
					module.element.find('[name="shop-email"]').val('');
					module.element.find('[name="shop-phone"]').val('');
					module.element.find('[name="shop-address"]').val('');
					utils.createMessage('success', 'shop updated');
				}
			});
		}
	});

	var addShop_control = fw.Control({
		init: function () {
			var module = this;
			this.active = false;
			app.msg_map.bind('active_module', function(e){
				if(e.new_val == 'addShop'){
					module.active = true;
					module.element.removeClass('hidden');
				}else{
					module.active = false;
					module.element.addClass('hidden');
				}
			});
		},
		reset: function () {
			var module = this;
			module.element.find('form')[0].reset();
		},
		'.upload click': function () {
			$(this).closest('form').find('input[type="file"]').trigger('click');
		},
		'.create click': function (e) {
			e.preventDefault();
			var module = e.data.self;

			var title = module.element.find('[name="shop-title"]').val();
			var email = module.element.find('[name="shop-email"]').val();
			var phone = module.element.find('[name="shop-phone"]').val();
			var address = module.element.find('[name="shop-address"]').val();

			if(!title || !email || !phone || !address){
				utils.createMessage('danger', 'Empty field');
				return false;
			}

			var model = new app.models.Shop({
				user_id: app.user,
				title: title,
				email: email,
				phone: phone,
				address: address
			});

			model.create(function (res) {
				if(res.ok){
					utils.createMessage('success', 'shop created');
					window.location.hash = 'cabinet';
				}
			});
		}
	});

	var cabinet_control = fw.Control({
		init: function () {
			var module = this;
			this.active = false;
			this.limit = 12;
			this.offset = 0;
			this.scroll = false;
			app.msg_map.bind('active_module', function(e){
				if(e.new_val == 'cabinet'){
					module.active = true;
					module.element.removeClass('hidden');
				}else{
					module.active = false;
					module.element.addClass('hidden');
				}
			});
		},
		start: function () {
			this.offset = 0;
			this.getShops();
		},
		getShops: function () {
			var module = this;
			var offset = module.offset || 0;
			var limit = module.limit;
			var is_first = (offset) ? false : true;

			app.models.Shop.find( {offset: offset, limit: limit, user_id: app.user}, function(res){
				if(is_first){
					module.element.find('.items-wrap').html(fw.view('./js/app/cabinet/shopListItem.ejs', { 
						items: res.items
					}));
				}else{
					module.element.find('.items-wrap').append(fw.view('./js/app/cabinet/shopListItem.ejs', { 
						items: res.items
					}));
				}
		
				if(res.count > offset + limit) module.scroll.active = true;
				else module.scroll.active = false;	

				if(module.element.find('.items-wrap')[0].clientHeight < $(window).height() && module.scroll.active){
					module.onscroll();
				}	

			});
		},
		'.add-shop click': function () {
			window.location.hash = 'addShop';
		},
		'.remove-btn click': function (id) {
			var shop = $(this).closest('.item-wrap');
			var shopId = shop.attr('data-id');
			console.log(shopId);
			var asc = confirm('Are you shure?');
			if(asc){
				var model = new app.models.Shop({id:shopId});
				model.destroy(function (res) {
					shop.remove();
				});
			}
			
		},
		'.edit-btn click': function (id) {
			var shop = $(this).closest('.item-wrap');
			var shopId = shop.attr('data-id');
			window.location.hash = 'editShop/'+shopId;
		},
		scrollInit: function () {
			var module = this;
			module.scroll = {
				active: false,
				element: module.element.find('.items-wrap')
			};
			$(document).on('scroll', module.onscroll);
			$(window).on('resize', module.onscroll);
		},
		onscroll: function () {
			var module = cabinet.control;
			var scroll = module.scroll;
			
			if(!module.active || !scroll.active) return false;
			
			if  ($(document).scrollTop() + $(window).height() >= scroll.element.offset().top + scroll.element.height()-100) 
		    {
		    	scroll.active = false;
		    	module.offset = module.element.find('.items-wrap .shopListItem').length;
		    	module.getShops();
		    }
		},
	});

	fw.route.add('cabinet', function(){
		if(cabinet.control.active) return false;
		if(!app.user){
			window.location.hash='shopList';
			return false;
		} 
		cabinet.control.start();
		app.msg_map.trigger( 'change', 'active_module', '', 'cabinet');
	});
	fw.route.add('addShop', function(){
		if(cabinet.addShop.active) return false;
		if(!app.user){
			window.location.hash='shopList';
			return false;
		} 
		cabinet.addShop.reset();
		app.msg_map.trigger( 'change', 'active_module', '', 'addShop');
	});
	fw.route.add('editShop/([0-9]+)', function(params){
		if(cabinet.editShop.active) return false;
		if(!app.user){
			window.location.hash='shopList';
			return false;
		} 
		cabinet.editShop.getShop(params[0]);
		app.msg_map.trigger( 'change', 'active_module', '', 'editShop');
	});
	fw.route.add('editProduct/([0-9]+)', function(params){
		if(cabinet.editProduct.active) return false;
		if(!app.user){
			window.location.hash='shopList';
			return false;
		} 
		cabinet.editProduct.getProduct(params[0]);
		app.msg_map.trigger( 'change', 'active_module', '', 'editProduct');
	});
	
});