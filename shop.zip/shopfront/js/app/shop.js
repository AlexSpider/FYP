define(['jfw.core', 'jquery', 'jfw.control', 'jfw.route', 'jfw.view', 'app/models', 'app/msg_map'], 

	function(fw, $){

		var app = fw.extend(fw, 'app');
		var shop = fw.extend(fw, 'app.shop');

		shop._init = function(){
			$('#layout').append(fw.view('./js/app/shop/layout.ejs', {}));

			shop.control = new Shop_control('#shop-module');

		};

	var Shop_control = fw.Control({
		init: function () {
			var module = this;
			this.active = false;
			this.shopId = 0;
			this.limit = 12;
			this.offset = 0;
			this.scroll = false;
			app.msg_map.bind('active_module', function(e){
				if(e.new_val == 'shop'){
					module.active = true;
					module.element.removeClass('hidden');
				}else{
					module.offset = 0;
					module.active = false;
					module.scrollDestroy();
					module.element.addClass('hidden');
				}
			});
		},
		getShop: function (id) {
			var module = this;
			module.shopId = id;
			app.models.Shop.findOne( {id: id}, function(res){

				module.element.html(fw.view('./js/app/shop/shopLayout.ejs', { 
					shop: res.shop
				}));
				
				module.scrollInit();
				module.getShopProducts(res.shop.ID);

			});
		},
		getShopProducts: function (shopId) {
			var module = this;
			var offset = module.offset || 0;
			var limit = module.limit;
			var is_first = (offset) ? false : true;

			app.models.Products.find( {shop_id: shopId, offset: offset, limit: limit}, function(res){
				if(is_first){
					module.element.find('.items-wrap').html(fw.view('./js/app/shop/shopProductsList.ejs', { 
						items: res.items
					}));
				}else{
					module.element.find('.items-wrap').append(fw.view('./js/app/shop/shopProductsList.ejs', { 
						items: res.items
					}));
				}
		
				if(res.count > offset + limit) module.scroll.active = true;
				else module.scroll_active = false;	

				if(module.element.find('.items-wrap')[0].clientHeight < $(window).height() && module.scroll.active){
					module.onscroll();
				}	

			});
		},
		scrollInit: function () {
			var module = this;
			module.scroll = {
				active: false,
				element: module.element.find('.items-wrap')
			};
			$(document).on('scroll', module.onscroll);
			$(window).on('resize', module.onscroll);
		},
		scrollDestroy: function () {
			var module = this;
			module.scroll = false;
			$(document).off('scroll', module.onscroll);
			$(window).off('resize', module.onscroll);
		},
		onscroll: function () {

			var module = shop.control;
			var scroll = module.scroll;
			
			if(!module.active || !scroll.active) return false;
			
			if  ($(document).scrollTop() + $(window).height() >= scroll.element.offset().top + scroll.element.height()-100) 
		    {
		    	scroll.active = false;
		    	module.offset = module.element.find('.items-wrap .productItem').length;
		    	module.getShopProducts(module.shopId);
		    }
		},
	});

	fw.route.add('shop/([0-9]+)', function(params){
		if(shop.control.active) return false;

		if(params[0]){
			shop.control.getShop(+params[0])
		}else{
			throw new Error("Shop not found");
		}
		app.msg_map.trigger( 'change', 'active_module', '', 'shop');
	});
});