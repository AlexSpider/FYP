define(['jfw.core', 'jquery', 'jfw.control', 'jfw.route', 'jfw.view', 'app/models', 'app/msg_map', 'app/utils'], 

	function(fw, $){

		var app = fw.extend(fw, 'app');
		var shopList = fw.extend(fw, 'app.shopList');
		var utils = fw.extend(fw, 'app.utils');

		shopList._init = function(){
			$('#layout').append(fw.view('./js/app/shopList/layout.ejs', {}));

			shopList.control = new shopList_control('#shopList-module');
			shopList.control.scrollInit();

		};

	var shopList_control = fw.Control({
		init: function () {
			var module = this;
			this.active = false;
			this.limit = 12;
			this.offset = 0;
			this.scroll = false;
			app.msg_map.bind('active_module', function(e){
				if(e.new_val == 'shopList'){
					module.active = true;
					module.element.removeClass('hidden');
				}else{
					module.active = false;
					module.element.addClass('hidden');
				}
			});
		},
		start: function () {
			this.offset = 0;
			this.getShops();
		},
		getShops: function () {
			var module = this;
			var offset = module.offset || 0;
			var limit = module.limit;
			var is_first = (offset) ? false : true;

			app.models.Shop.find( {offset: offset, limit: limit}, function(res){
				if(is_first){
					module.element.find('.items-wrap').html(fw.view('./js/app/shopList/shopListItem.ejs', { 
						items: res.items
					}));
				}else{
					module.element.find('.items-wrap').append(fw.view('./js/app/shopList/shopListItem.ejs', { 
						items: res.items
					}));
				}
		
				if(res.count > offset + limit) module.scroll.active = true;
				else module.scroll.active = false;	

				if(module.element.find('.items-wrap')[0].clientHeight < $(window).height() && module.scroll.active){
					module.onscroll();
				}	

			},function (res) {
				utils.createMessage('danger', 'error');
			});
		},
		scrollInit: function () {
			var module = this;
			module.scroll = {
				active: false,
				element: module.element.find('.items-wrap')
			};
			$(document).on('scroll', module.onscroll);
			$(window).on('resize', module.onscroll);
		},
		onscroll: function () {
			var module = shopList.control;
			var scroll = module.scroll;
			
			if(!module.active || !scroll.active) return false;
			
			if  ($(document).scrollTop() + $(window).height() >= scroll.element.offset().top + scroll.element.height()-100) 
		    {
		    	scroll.active = false;
		    	module.offset = module.element.find('.items-wrap .shopListItem').length;
		    	module.getShops();
		    }
		},
	});

	fw.route.add('shopList', function(){
		if(shopList.control.active) return false;
		shopList.control.start();
		app.msg_map.trigger( 'change', 'active_module', '', 'shopList');
	});
});