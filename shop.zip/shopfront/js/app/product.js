define(['jfw.core', 'jquery', 'jfw.control', 'jfw.route', 'jfw.view', 'app/models', 'app/msg_map'], 

	function(fw, $){

		var app = fw.extend(fw, 'app');
		var product = fw.extend(fw, 'app.product');

		product._init = function(){
			$('#layout').append(fw.view('./js/app/product/layout.ejs', {}));

			product.control = new Product_control('#product-module');

		};

	var Product_control = fw.Control({
		init: function () {
			var module = this;
			this.active = false;
			this.productId = 0;
			app.msg_map.bind('active_module', function(e){
				if(e.new_val == 'product'){
					module.active = true;
					module.element.removeClass('hidden');
				}else{
					module.active = false;
					module.element.addClass('hidden');
				}
			});
		},
		getProduct: function (id) {
			var module = this;
			module.productId = id;
			app.models.Products.findOne( {id: id}, function(res){

				module.element.html(fw.view('./js/app/product/productLayout.ejs', { 
					product: res.product
				}));
				

			});
		},
	});

	fw.route.add('product/([0-9]+)', function(params){
		if(product.control.active) return false;

		if(params[0]){
			product.control.getProduct(+params[0]);
		}else{
			throw new Error("Product not found");
		}
		app.msg_map.trigger( 'change', 'active_module', '', 'product');
	});
});