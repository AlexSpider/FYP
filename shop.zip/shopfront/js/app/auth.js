define(['jfw.core', 'jquery', 'jfw.control', 'jfw.route', 'jfw.view', 'app/models', 'app/msg_map', 'app/utils'], 

	function(fw, $){

		var app = fw.extend(fw, 'app');
		var auth = fw.extend(fw, 'app.auth');
		var utils = fw.extend(fw, 'app.utils');

		auth._init = function(){
			$('#layout').append(fw.view('./js/app/auth/layout.ejs', {}));

			$('#authTabs a').click(function (e) {
  				e.preventDefault()
  				$(this).tab('show')
			})

			auth.control = new Auth_control('#auth-module');

		};

		auth.login = function (user) {
			app.user = user;
			localStorage.setItem('user',user);
			$('#login-btn').addClass('hidden');
			$('#cabinet-btn').removeClass('hidden');
			$('#logout-btn').removeClass('hidden');
			if(window.location.hash == '#login'){
				window.location.hash = 'cabinet';
			}
		}

		auth.logout = function () {
			app.user = false;
			localStorage.removeItem('user');
			$('#login-btn').removeClass('hidden');
			$('#cabinet-btn').addClass('hidden');
			$('#logout-btn').addClass('hidden');
			window.location.hash = 'shopList';
		}

	var Auth_control = fw.Control({
		init: function () {
			var module = this;
			this.active = false;
			app.msg_map.bind('active_module', function(e){
				if(e.new_val == 'login'){
					module.active = true;
					module.element.removeClass('hidden');
				}else{
					module.active = false;
					module.element.addClass('hidden');
				}
			});
		},
		'#login-form submit': function (e) {
			e.preventDefault();
			var module = e.data.self;
			var form = $(this);

			var emailInp = $('#login-email');
			var passInp = $('#login-pass');
			var email = emailInp.val();
			var pass = passInp.val();

			if(!email || !pass){
				utils.createMessage('danger', 'Empty field');
				return false;
			}

			app.models.Users.find( {email: email, pass: pass}, function(res){

				if(res.ok){
					emailInp.val('');
					passInp.val('');

					auth.login(res.user);
				}else{
					utils.createMessage('danger', 'Wrong email or password');
				}

			});
		},
		'#reg-form submit': function (e) {
			e.preventDefault();
			var module = e.data.self;
			var form = $(this);

			var emailInp = $('#reg-email');
			var passInp = $('#reg-pass');
			var confpassInp = $('#reg-confpass');

			var email = emailInp.val();
			var pass = passInp.val();
			var confpass = confpassInp.val();

			if(!email || !pass || !confpass){
				utils.createMessage('danger', 'Empty field');
				return false;
			}

			if(pass != confpass){
				utils.createMessage('danger', 'Passwords not match');
				return false;
			}

			var model = new app.models.Users({email: email, pass: pass});
			model.create(function(res){
				if(res.ok){
					utils.createMessage('success', 'thanks for registration');
				}else{
					if(res.err == 205){
						utils.createMessage('danger', 'email exist');
					}else{
						console.error("Server error");
					}
				}
			});
		}
	});

	fw.route.add('login', function(){
		if(app.user) window.location.hash = 'cabinet';
		else app.msg_map.trigger( 'change', 'active_module', '', 'login');
	});

	fw.route.add('logout', function(){
		auth.logout();
	});

});