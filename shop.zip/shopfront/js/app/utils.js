define(['jfw.core', 'jquery'], 

	function(fw, $){

		var app = fw.extend(fw, 'app');
		var utils = fw.extend(fw, 'app.utils');

		var wrapper = $('<div />',{
			id:'alert_message',
		});

		$('body').append(wrapper);

		utils.createMessage = function(status, messages){
			var type = Object.prototype.toString.call(messages).slice(8, -1);

			var $div = $('<div/>',{
				"class": "alert alert-" + status,
				"click" : function () {
					$div.remove();
				}
			});

			if(type == 'String'){
				$div.append('<p>'+messages+'</p>');
			}else if(type == 'Array'){
				var message = '';
				for (var i = 0, l =  messages.length; i < l; i++) {
					message += '<p>'+messages[i]+'</p>';
				};
				$div.append(message);
			}

			wrapper.append($div);

			setTimeout(function () {
				if(!$div) return false;
				$div.fadeOut(function () {
					$div.remove();
				});
			}, 3000)
		}

	}
);