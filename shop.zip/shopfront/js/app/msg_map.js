define(['../jfw.core',], function(fw){
	var app = fw.extend(fw, 'app');
	app.msg_map = new fw.Map();
});