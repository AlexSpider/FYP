define(['jfw.model'], function(fw){
	var models = fw.extend(fw, 'app.models');

	fw.Model.baseUrl = 'http://shopbackend:8081';

	models.Shop = fw.Model({
		find: 'GET /shop/list',
		findOne: 'GET /shop/one',
		destroy: 'GET /shop/remove',
		create: 'POST /shop/add',
		update: 'POST /shop/edit'
	});

	models.Products = fw.Model({
		find: 'GET /product/list',
		findOne: 'GET /product/one',
		destroy: 'GET /product/remove',
		create: 'POST /product/add',
		update: 'POST /product/edit',
	});

	models.Users = fw.Model({
		find: 'POST /user/login',
		create: 'POST /user/reg',
	});

});