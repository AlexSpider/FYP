define(['jfw.core', 'jfw.model'], function(fw){

    fw.Model.fixture('POST /shop/edit', function(req, res){
        
        var id = req.data.id;
        var title = req.data.title;
        var descr = req.data.descr;

        for (var i = 0, l = shops.length; i < l; i++) {
            if(shops[i].id == id){
                shops[i].title = title;
                shops[i].descr = descr;
                break;
            }
        };
       
        res({
            ok:1,
        })
    });


});
