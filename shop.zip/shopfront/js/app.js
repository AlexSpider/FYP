/**
    SBNLife frontend application
    Copyright (c) 2014-2015, ITLid All Rights Reserved.

    @version 0.1.0
    @author ITLid <info@itlid.com.ua>
*/

requirejs.config({
	baseUrl: 'js',
	paths: {
    	jquery: 'jquery-1.11.1.min',
    	bootstrap: 'bootstrap.min',
    },
});

require([
        'jfw.core', 'jquery', 'app/msg_map', 'app/shopList', 'jfw.view', 'bootstrap', 'jfw.route',
        'app/shop', 'app/product', 'app/auth', 'app/cabinet'
    ], function(fw, $){

    var app = fw.extend(fw, 'app');

    
    $.ajax({
        url: './js/config.json',
        type: 'GET',
        dataType: 'json',
        success: function(data){
            window.baseUrl = data.baseUrl;
            app.config = data;
            app.shopList._init();
            app.shop._init();
            app.product._init();
            app.auth._init();
            app.cabinet._init();

            var user = localStorage.getItem('user');
            if(user){
                app.user = user;
                app.auth.login(user);
            }

            if(!window.location.hash) window.location.hash = 'shopList';
            else  fw.route.trigger('hash', 'change', '', window.location.hash);

        },
        error: function (e) {
            console.error('config not found');
        }
    });
    window.fw = fw;
});